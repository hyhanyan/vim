For information about installation of Farsi fonts and Vim usage in Farsi mode,
refer to the Farsi help file by typing ":help farsi" in Vim.
